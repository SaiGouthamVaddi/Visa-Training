public class Swapper 
{
	int val1, val2;
	
	public int[] swap(int num1,int num2)
	{
		num1  = num1 + num2;
		num2  = num1 - num2;
		num1  = num1 - num2;
		int[] array = {num1,num2};
		return array;
	}
	
		
}
