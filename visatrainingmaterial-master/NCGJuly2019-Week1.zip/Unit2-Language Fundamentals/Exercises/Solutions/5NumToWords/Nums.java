
public class Nums {

	public static void main(String[] args) {
		NumberToWordsConvertor convertor = new NumberToWordsConvertor();
		String s = convertor.NumToWord(1023);
		System.out.println(s);

	}

}
