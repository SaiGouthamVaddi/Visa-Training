
public class ElementFinder {
	public int search(int[] values, int item){
		int notFound = -1;
		int len = values.length;

		for(int i = 0; i < len; i++)
			if(item == values[i])
				return (i+1);
		return notFound;
	}
}
