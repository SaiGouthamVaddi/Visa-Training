public class NumberToWordsConvertor 
{
	
	String[] words = {"ZERO","ONE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE"};
	
	public String NumToWord(int val)
	{
		int rev = 0;
		String str = "";	
		while ( val > 0 )
		{
			rev   = rev * 10 + val % 10;
			val   = val / 10;
		}

		while ( rev >0 )
		{
			System.out.println(words[(rev % 10)]);
			str = str + (words[(rev % 10)] + ",");
			rev = rev / 10;
		}
	 return str;
	}
}
