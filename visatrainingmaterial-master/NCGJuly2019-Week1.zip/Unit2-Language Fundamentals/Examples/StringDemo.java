class StringDemo 
{
	public static void main(String[] args) 
	{
		String firstName = new String("James ");
		String lastName = new String("Gosling");
		String companyName = "Sun MicroSystems";

		System.out.println("Java was developed at " + companyName + 
											" by " + firstName + lastName);
	}
}
