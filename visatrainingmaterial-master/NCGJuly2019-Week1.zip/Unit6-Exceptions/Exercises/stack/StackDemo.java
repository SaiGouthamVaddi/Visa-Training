

import java.util.Scanner;

public class StackDemo {

	public static void main(String[] args) throws StackEmptyException {
		
		
		
		StackUser user = new StackUser();
		FixedArrayStack s = new FixedArrayStack(10);
		
			user.fillUp(s);
		
		System.out.println("------------------------");
		user.empty(s);

	}

}
