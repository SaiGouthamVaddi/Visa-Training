public class DecimalSplit
{
	final private int PRECISION = 6;

	public int getWhole(double decimal)
	{
			int whole = (int)(decimal);			
			return whole;
	}
	public double getFraction(double decimal)
	{
		double fraction = decimal - getWhole(decimal);
		System.out.println(fraction);
		return fraction;	
	}

	public static void main(String[] args)
	{
		DecimalSplit obj = new DecimalSplit();
		double val = 12.38;
		int whole = obj.getWhole(val);
		double fraction = obj.getFraction(val);
		System.out.println(whole+"  "+fraction);
	}
}