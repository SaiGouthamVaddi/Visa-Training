public class Swap
{
	

	
	public static void main(String[] args)
	{
		Swapper swapper = new Swapper();
		int n1 = 10;
		int n2 = 20;
		int[] swapped = swapper.swap(n1,n2);
		System.out.println(int[0]+" "+int[1]);
	}
	
}