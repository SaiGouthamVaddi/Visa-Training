
public class TestResultCalculator {

	public String getResult(int i,int j,int k){
		String result;
		int total = i + j + k;
		float avg = total/3;
		
		if ((i > 35) && (j > 35) && (k > 35)){
			if(avg >= 60){
				result = "First";
			}else if(avg >= 50){
				result = "Second";
			}else 
				result = "Pass";
		}else
			result="Fails";
		
		return result + ":" + total + ":" + avg;
	}
}
