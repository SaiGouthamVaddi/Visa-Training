public class MatrixWizard{
	public boolean isIdentity(int[][] matrix){
			boolean isIdentity = true;	
			
			for(int i=0;i<matrix.length;i++)
				for(int j=0;j<matrix.length;j++){
					if(i == j){
						if(matrix[i][j] != 1){
							isIdentity = false;
							break;
						}
					}else{
						if(matrix[i][j] != 0){
							isIdentity = false;
							break;
						}
					}
				}
			return isIdentity;
	}

	public boolean isSymmetric(int[][] matrix){
		boolean isSymmetric = true;
		
		for(int i=0;i<matrix.length;i++)
			for(int j=0;j<matrix.length;j++)
				if(matrix[i][j] != matrix[j][i]){
					isSymmetric = false;
					break;
				}
		return isSymmetric;	
	}
}